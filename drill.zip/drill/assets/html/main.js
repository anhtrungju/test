const nw = require('nw.gui');
nw.Window.open('index.html', {}, function(win) {});