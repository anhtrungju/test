
# Generic Game

A *fartastic* adventure

Bitmap font generator:
https://snowb.org/

Music: ETC

Royalty Free banjo music
https://www.youtube.com/watch?v=Q31_WCSmD-s