TODO:
- ~~Stars from beginning~~
- ~~Correct container position~~
- ~~Colliders with containers~~
- ~~Progress bar for damage~~ 
- ~~Camera zoom with more containers~~
- ~~Show No of containers on adding~~
- ~~Player dying~~
- Show stations to stop
- Containers go away when dying
- Thruster anim
- Add sounds: horn, hit, hit between asteroids, pick, thrust
- Adds music
- Adds logo
BUGS
- Open world bounds
- ~~Sometimes container bad~~